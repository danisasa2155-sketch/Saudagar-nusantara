JELAJAH REMPAH NUSANTARA — PROYEK APLIKASI ANDROID

Kode game asli disimpan tanpa perubahan di:
app/src/main/assets/index.html

Aplikasi membuka HTML lokal di dalam Android WebView. Dengan demikian, game tidak perlu mengambil halaman dari Netlify saat dijalankan. Progress game tetap menggunakan penyimpanan lokal WebView pada perangkat.

CARA MEMBANGUN APK
1. Ekstrak folder proyek ini.
2. Buka Android Studio.
3. Pilih Open dan pilih folder SaudagarNusantaraAndroid.
4. Tunggu Gradle sync selesai dan izinkan pemasangan komponen SDK yang diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.

Catatan: Paket ini adalah proyek sumber Android, belum berupa APK yang sudah dikompilasi. Build membutuhkan Android Studio/Android SDK dan koneksi internet untuk mengunduh komponen build pertama kali.
